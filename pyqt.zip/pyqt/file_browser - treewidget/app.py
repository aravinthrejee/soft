import sys,os
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
from PyQt5 import QtGui as qtg
import ui

class Myapp(ui.Ui_MainWindow,qtw.QMainWindow):
    def __init__(self):
        super(Myapp,self).__init__()
        self.setupUi(self)
        self.populate()
    def populate(self):
        path = r"C:\Users\007644\Documents\009367\pyqt"
        for item in os.listdir(path):
            item_path=os.path.join(path,item)
            if os.path.isdir(item_path):
                self.parent=qtw.QTreeWidgetItem(self.treeWidget,[item])
                self.parent.setCheckState(0,0)
                self.parent.setIcon(0,qtg.QIcon('folder.png'))
                # if len(os.listdir(path)>0):
                    # for item in os.listdir(path):
                    #     self.d1=qtw.QTreeWidgetItem(self.treeWidget,[item])
                    #     self.d1.setCheckState(0,0)
                    #     if os.path.isdir(item):
                            
                            
            else:
                self.f1=qtw.QTreeWidgetItem(self.treeWidget,[item])
                self.f1.setCheckState(0,0)
                self.f1.setIcon(0,qtg.QIcon('file.png'))
    def sub_item_populate(self,path,parent):
        for item in os.listdir(path):
            self.out=qtw.QTreeWidgetItem(parent,[item])
            self.out.checkState(0,0)
        
            


if __name__ == "__main__":
    import sys
    app = qtw.QApplication(sys.argv)
    MainWindow = Myapp()
    MainWindow.show()
    sys.exit(app.exec_())
    

    