import sys
from PyQt5 import QtWidgets as qtw
from PyQt5 import QtCore as qtc
import ui

class Myapp(ui.Ui_MainWindow,qtw.QMainWindow):
    def __init__(self):
        super(Myapp,self).__init__()
        self.setupUi(self)
        self.populate()
    def populate(self):
        path = r"C:\Users\007644\Documents\009367\pyqt"
        self.model = qtw.QFileSystemModel()
        self.model.setRootPath((qtc.QDir.rootPath()))
        self.treeView.setModel(self.model)
        self.treeView.setRootIndex(self.model.index(path))
        self.treeView.setSortingEnabled(True)
        


if __name__ == "__main__":
    import sys
    app = qtw.QApplication(sys.argv)
    MainWindow = Myapp()
    MainWindow.show()
    sys.exit(app.exec_())
    

    