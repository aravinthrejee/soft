import sys
from PyQt5 import QtWidgets as QtW

def window():
    app=QtW.QApplication(sys.argv)
    win=QtW.QMainWindow()
    win.setGeometry(100,100,400,400)
    win.setWindowTitle('Shooting Star')
    label1=QtW.QLabel(win)
    label1.setText('Hello World')
    label1.setGeometry(120,120,50,50)

    b1=QtW.QPushButton(win)
    b1.setText('ADD')
    b1.clicked.connect(clicked)

    win.show()
    sys.exit(app.exec_())
def clicked():
    print('Clicked')
    


if __name__ == "__main__":
    window()