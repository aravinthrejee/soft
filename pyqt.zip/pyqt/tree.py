import sys
from PyQt5 import QtWidgets as QtW
class Myapp(QtW.QMainWindow):
    def __init__(self):
        super(Myapp,self).__init__()
        self.setGeometry(200,200,300,300)
        self.initui()
        self.setWindowTitle('Show Troppers')


    def initui(self):
        self.label1=QtW.QLabel(self)
        self.label1.setText('Hello World')
        self.label1.setGeometry(120,120,50,50)

        self.b1=QtW.QPushButton(self)
        self.b1.setText('ADD')
        self.b1.clicked.connect(self.clicked)
        self.tr1=QtW.QTreeWidget(self)
        self.tr1.setHeaderLabels(['Path','selected'])
        self.a1=QtW.QTreeWidgetItem(self.tr1,['C:'])
        self.a1.setCheckState(0,0)
        self.a2=QtW.QTreeWidgetItem(self.a1,['Pics','345KB'])
        self.a2.setCheckState(0,0)
        self.a2=QtW.QTreeWidgetItem(self.a1,['Docs','556KB'])
        self.a2.setCheckState(0,0)
        
        
        self.tr1.setGeometry(0,0,300,300)

    def clicked(self):
        self.label1.setText('Changed Changed')
        self.label1.adjustSize()
        
def window():
    app=QtW.QApplication(sys.argv)
    win=Myapp()
    win.show()
    sys.exit(app.exec_())

if __name__ == "__main__":
    window()