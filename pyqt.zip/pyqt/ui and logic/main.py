import sys
from PyQt5 import QtWidgets as qtw
import ui

class MyWindow(ui.Ui_MainWindow,qtw.QMainWindow):
    def __init__(self):
        super(MyWindow,self).__init__()
        self.setupUi(self)
        self.pushButton_1.clicked.connect(self.add_clicked)
        self.pushButton_2.clicked.connect(self.clear_clicked)
    def add_clicked(self):        
        self.label_1.setText('Hello World')
        self.label_1.adjustSize()
    def clear_clicked(self):
        self.label_1.clear()
        self.label_1.adjustSize()


if __name__ == "__main__":
    import sys
    app = qtw.QApplication(sys.argv)
    MainWindow = MyWindow()
    MainWindow.show()
    sys.exit(app.exec_())